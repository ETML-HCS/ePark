<img
    src="{{ asset('logo/ePark.png') }}"
    alt="ePark"
    {{ $attributes->merge(['class' => 'h-8 w-auto']) }}
/>
