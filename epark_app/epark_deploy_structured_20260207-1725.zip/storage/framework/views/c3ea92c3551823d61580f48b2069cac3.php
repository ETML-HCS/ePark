<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Indisponibilités - <?php echo e($place->nom); ?></h2>
     <?php $__env->endSlot(); ?>

    <div class="container space-y-8">
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="bg-white shadow-sm rounded-lg p-6">
            <h3 class="text-lg font-semibold">Indisponibilités hebdomadaires</h3>
            <p class="text-sm text-gray-500 mt-1">Les plages ci-dessous sont les heures NON reservables.</p>
            <form method="POST" action="<?php echo e(route('places.availability.update', $place->id)); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-4 flex flex-wrap gap-2">
                    <button type="button" class="px-3 py-1.5 text-xs rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100" data-clear-slot data-day="all">
                        Tout laisser libre
                    </button>
                    <button type="button" class="px-3 py-1.5 text-xs rounded-lg bg-indigo-50 text-indigo-700 hover:bg-indigo-100" data-quick-slot data-day="all" data-start="00:00" data-end="23:59">
                        Tout bloquer : journee entiere
                    </button>
                    <button type="button" class="px-3 py-1.5 text-xs rounded-lg bg-indigo-50 text-indigo-700 hover:bg-indigo-100" data-quick-slot data-day="all" data-start="07:30" data-end="17:00">
                        Tout bloquer : 07:30-17:00
                    </button>
                    <button type="button" class="px-3 py-1.5 text-xs rounded-lg bg-indigo-50 text-indigo-700 hover:bg-indigo-100" data-quick-slot data-day="all" data-start="07:30" data-end="12:00">
                        Tout bloquer : 07:30-12:00
                    </button>
                    <button type="button" class="px-3 py-1.5 text-xs rounded-lg bg-indigo-50 text-indigo-700 hover:bg-indigo-100" data-quick-slot data-day="all" data-start="12:00" data-end="17:30">
                        Tout bloquer : 12:00-17:30
                    </button>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dayIndex => $dayLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $slot = $availabilityByDay->get($dayIndex);
                        ?>
                        <div class="border rounded p-3">
                            <div class="font-medium mb-2"><?php echo e($dayLabel); ?></div>
                            <div class="flex gap-2">
                                <input type="time" name="availability[<?php echo e($dayIndex); ?>][start]" class="form-control" data-role="start" data-day="<?php echo e($dayIndex); ?>" value="<?php echo e($slot->start_time ?? ''); ?>">
                                <input type="time" name="availability[<?php echo e($dayIndex); ?>][end]" class="form-control" data-role="end" data-day="<?php echo e($dayIndex); ?>" value="<?php echo e($slot->end_time ?? ''); ?>">
                            </div>
                            <div class="mt-2 flex flex-wrap gap-2">
                                <button type="button" class="px-2 py-1 text-xs rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100" data-clear-slot data-day="<?php echo e($dayIndex); ?>">
                                    Laisser libre
                                </button>
                                <button type="button" class="px-2 py-1 text-xs rounded-lg bg-gray-100 hover:bg-gray-200" data-quick-slot data-day="<?php echo e($dayIndex); ?>" data-start="00:00" data-end="23:59">
                                    Bloquer journee entiere
                                </button>
                                <button type="button" class="px-2 py-1 text-xs rounded-lg bg-gray-100 hover:bg-gray-200" data-quick-slot data-day="<?php echo e($dayIndex); ?>" data-start="07:30" data-end="17:00">
                                    Bloquer 07:30-17:00
                                </button>
                                <button type="button" class="px-2 py-1 text-xs rounded-lg bg-gray-100 hover:bg-gray-200" data-quick-slot data-day="<?php echo e($dayIndex); ?>" data-start="07:30" data-end="12:00">
                                    Bloquer 07:30-12:00
                                </button>
                                <button type="button" class="px-2 py-1 text-xs rounded-lg bg-gray-100 hover:bg-gray-200" data-quick-slot data-day="<?php echo e($dayIndex); ?>" data-start="12:00" data-end="17:30">
                                    Bloquer 12:00-17:30
                                </button>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="mt-4">
                    <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Enregistrer <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
                </div>
            </form>
        </div>

        <div class="bg-white shadow-sm rounded-lg p-6">
            <h3 class="text-lg font-semibold mb-4">Indisponibilités exceptionnelles</h3>
            <form method="POST" action="<?php echo e(route('places.unavailability.store', $place->id)); ?>" class="grid grid-cols-1 md:grid-cols-4 gap-3 items-end">
                <?php echo csrf_field(); ?>
                <div>
                    <label class="form-label">Date</label>
                    <input type="date" name="date" class="form-control" required>
                </div>
                <div>
                    <label class="form-label">Début (optionnel)</label>
                    <input type="time" name="start_time" class="form-control">
                </div>
                <div>
                    <label class="form-label">Fin (optionnel)</label>
                    <input type="time" name="end_time" class="form-control">
                </div>
                <div>
                    <label class="form-label">Motif</label>
                    <input type="text" name="reason" class="form-control" placeholder="Travaux, privé...">
                </div>
                <div class="md:col-span-4">
                    <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Ajouter <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
                </div>
            </form>

            <div class="mt-6">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Plage</th>
                            <th>Motif</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $unavailabilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exception): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($exception->date->format('Y-m-d')); ?></td>
                                <td>
                                    <?php if($exception->start_time && $exception->end_time): ?>
                                        <?php echo e($exception->start_time); ?> - <?php echo e($exception->end_time); ?>

                                    <?php else: ?>
                                        Journée entière
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($exception->reason ?? '-'); ?></td>
                                <td class="text-end">
                                    <form method="POST" action="<?php echo e(route('places.unavailability.destroy', [$place->id, $exception->id])); ?>" onsubmit="return confirm('Supprimer cette indisponibilité ?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <?php if (isset($component)) { $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.danger-button','data' => ['class' => 'px-3 py-1 text-sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'px-3 py-1 text-sm']); ?>Supprimer <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $attributes = $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $component = $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="4">Aucune indisponibilité.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            document.addEventListener('click', (event) => {
                const button = event.target.closest('[data-quick-slot], [data-clear-slot]');
                if (!button) {
                    return;
                }

                const day = button.dataset.day;
                const start = button.dataset.start;
                const end = button.dataset.end;

                if (button.hasAttribute('data-clear-slot')) {
                    if (day === 'all') {
                        document.querySelectorAll('input[data-role="start"], input[data-role="end"]').forEach((input) => {
                            input.value = '';
                        });
                        return;
                    }

                    const startInput = document.querySelector(`input[data-role="start"][data-day="${day}"]`);
                    const endInput = document.querySelector(`input[data-role="end"][data-day="${day}"]`);
                    if (startInput) {
                        startInput.value = '';
                    }
                    if (endInput) {
                        endInput.value = '';
                    }
                    return;
                }

                if (day === 'all') {
                    document.querySelectorAll('input[data-role="start"]').forEach((input) => {
                        input.value = start;
                    });
                    document.querySelectorAll('input[data-role="end"]').forEach((input) => {
                        input.value = end;
                    });
                    return;
                }

                const startInput = document.querySelector(`input[data-role="start"][data-day="${day}"]`);
                const endInput = document.querySelector(`input[data-role="end"][data-day="${day}"]`);

                if (startInput) {
                    startInput.value = start;
                }

                if (endInput) {
                    endInput.value = end;
                }
            });
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH X:\Dev\f-web\ePark\epark_app\resources\views/places/availability.blade.php ENDPATH**/ ?>