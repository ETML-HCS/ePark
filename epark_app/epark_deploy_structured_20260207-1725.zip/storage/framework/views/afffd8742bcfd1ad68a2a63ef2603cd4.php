<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Back-office</h2>
     <?php $__env->endSlot(); ?>

    <div class="space-y-8">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-white shadow-sm rounded-xl border border-gray-100 p-5">
                <p class="text-sm text-gray-500">Utilisateurs</p>
                <p class="text-2xl font-bold"><?php echo e($stats['users']); ?></p>
            </div>
            <div class="bg-white shadow-sm rounded-xl border border-gray-100 p-5">
                <p class="text-sm text-gray-500">Sites</p>
                <p class="text-2xl font-bold"><?php echo e($stats['sites']); ?></p>
            </div>
            <div class="bg-white shadow-sm rounded-xl border border-gray-100 p-5">
                <p class="text-sm text-gray-500">Places</p>
                <p class="text-2xl font-bold"><?php echo e($stats['places']); ?></p>
            </div>
            <div class="bg-white shadow-sm rounded-xl border border-gray-100 p-5">
                <p class="text-sm text-gray-500">Réservations</p>
                <p class="text-2xl font-bold"><?php echo e($stats['reservations']); ?></p>
            </div>
            <div class="bg-white shadow-sm rounded-xl border border-gray-100 p-5">
                <p class="text-sm text-gray-500">Paiements</p>
                <p class="text-2xl font-bold"><?php echo e($stats['payments']); ?></p>
            </div>
            <div class="bg-white shadow-sm rounded-xl border border-gray-100 p-5">
                <p class="text-sm text-gray-500">Revenus (payés)</p>
                <p class="text-2xl font-bold"><?php echo e(number_format($stats['revenue'], 2, ',', ' ')); ?> €</p>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div class="bg-white shadow-sm rounded-xl border border-gray-100 overflow-hidden">
                <div class="px-5 py-4 border-b border-gray-100">
                    <h3 class="text-lg font-semibold">Dernières réservations</h3>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500">ID</th>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500">Client</th>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500">Place</th>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500">Statut</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y">
                            <?php $__empty_1 = true; $__currentLoopData = $recentReservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="px-4 py-3 text-sm">#<?php echo e($reservation->id); ?></td>
                                    <td class="px-4 py-3 text-sm"><?php echo e(optional($reservation->user)->name ?? 'N/A'); ?></td>
                                    <td class="px-4 py-3 text-sm"><?php echo e(optional($reservation->place)->nom ?? 'N/A'); ?></td>
                                    <td class="px-4 py-3 text-sm"><?php echo e($reservation->statut); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="4" class="px-4 py-6 text-center text-sm text-gray-500">Aucune réservation.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="bg-white shadow-sm rounded-xl border border-gray-100 overflow-hidden">
                <div class="px-5 py-4 border-b border-gray-100">
                    <h3 class="text-lg font-semibold">Derniers paiements</h3>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500">ID</th>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500">Client</th>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500">Montant</th>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500">Statut</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y">
                            <?php $__empty_1 = true; $__currentLoopData = $recentPayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="px-4 py-3 text-sm">#<?php echo e($payment->id); ?></td>
                                    <td class="px-4 py-3 text-sm"><?php echo e(optional(optional($payment->reservation)->user)->name ?? 'N/A'); ?></td>
                                    <td class="px-4 py-3 text-sm"><?php echo e(number_format(($payment->amount_cents ?? 0) / 100, 2, ',', ' ')); ?> €</td>
                                    <td class="px-4 py-3 text-sm"><?php echo e($payment->provider_status); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="4" class="px-4 py-6 text-center text-sm text-gray-500">Aucun paiement.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="bg-white shadow-sm rounded-xl border border-gray-100 overflow-hidden">
            <div class="px-5 py-4 border-b border-gray-100">
                <h3 class="text-lg font-semibold">Derniers utilisateurs</h3>
            </div>
            <div class="overflow-x-auto">
                <table class="min-w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500">Nom</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500">Email</th>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500">Rôle</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        <?php $__empty_1 = true; $__currentLoopData = $recentUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="px-4 py-3 text-sm"><?php echo e($user->name); ?></td>
                                <td class="px-4 py-3 text-sm"><?php echo e($user->email); ?></td>
                                <td class="px-4 py-3 text-sm"><?php echo e($user->role); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="3" class="px-4 py-6 text-center text-sm text-gray-500">Aucun utilisateur.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH X:\Dev\f-web\ePark\epark_app\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>