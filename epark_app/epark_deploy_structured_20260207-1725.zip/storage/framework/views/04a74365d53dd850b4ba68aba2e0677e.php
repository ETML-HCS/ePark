<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between">
            <h2 class="font-black text-2xl text-gray-900 flex items-center gap-3">
                <div class="p-2 bg-indigo-100 rounded-xl">
                    <svg class="w-6 h-6 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                </div>
                Mes Réservations
            </h2>
            <a href="<?php echo e(route('reservations.create')); ?>" aria-label="Nouvelle reservation" class="inline-flex items-center justify-center sm:justify-start gap-0 sm:gap-2 px-3 sm:px-6 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 hover:shadow-xl hover:shadow-indigo-300 transform hover:-translate-y-0.5">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                </svg>
                <span class="hidden sm:inline">Nouvelle réservation</span>
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-8 bg-gradient-to-b from-gray-50 to-white min-h-screen">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <?php if(session('success')): ?>
                <div class="mb-6 p-4 bg-green-50 border-l-4 border-green-500 rounded-xl flex items-center gap-3 shadow-sm animate-slide-in">
                    <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    <span class="font-medium text-green-800"><?php echo e(session('success')); ?></span>
                </div>
            <?php endif; ?>

            <!-- Filtres -->
            <div class="mb-6 bg-white rounded-2xl shadow-sm border border-gray-100 p-5" x-data="{ showFilters: false }">
                <div class="flex items-center justify-between">
                    <div class="flex items-center gap-4">
                        <button @click="showFilters = !showFilters" class="flex items-center gap-2 px-4 py-2 rounded-xl border-2 font-bold transition-all" :class="showFilters ? 'bg-indigo-50 text-indigo-600 border-indigo-200' : 'bg-white text-gray-600 border-gray-200 hover:border-gray-300'">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"></path>
                            </svg>
                            Filtrer
                        </button>
                        <div class="text-sm text-gray-500">
                            <span class="font-bold text-gray-900"><?php echo e($reservations->count()); ?></span> réservation(s)
                        </div>
                    </div>
                </div>
                <form method="GET" action="<?php echo e(route('reservations.index')); ?>" x-show="showFilters" x-transition class="mt-4 pt-4 border-t border-gray-100 grid grid-cols-1 md:grid-cols-3 gap-4">
                    <select name="period" class="rounded-xl border-gray-200 focus:ring-2 focus:ring-indigo-500">
                        <option value="upcoming" <?php echo e(request('period', 'upcoming') === 'upcoming' ? 'selected' : ''); ?>>Période : À venir</option>
                        <option value="past" <?php echo e(request('period') === 'past' ? 'selected' : ''); ?>>Période : Passées</option>
                        <option value="all" <?php echo e(request('period') === 'all' ? 'selected' : ''); ?>>Période : Toutes</option>
                    </select>
                    <button type="submit" class="px-4 py-2 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all">Appliquer</button>
                    <a href="<?php echo e(route('reservations.index')); ?>" class="px-4 py-2 bg-gray-100 text-gray-700 rounded-xl font-bold hover:bg-gray-200 transition-all text-center">Réinitialiser</a>
                </form>
            </div>

            <!-- Liste des réservations en cartes -->
            <div class="space-y-4">
                <?php $__empty_1 = true; $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 hover:shadow-lg transition-all duration-300 overflow-hidden group">
                        <div class="p-6">
                            <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                                <!-- Info principale -->
                                <div class="flex-1">
                                    <div class="flex items-start gap-4">
                                        <div class="p-3 bg-gradient-to-br from-indigo-400 to-purple-500 rounded-2xl shadow-lg flex-shrink-0">
                                            <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
                                            </svg>
                                        </div>
                                        <div class="flex-1">
                                            <h3 class="text-lg font-black text-gray-900 mb-1">#<?php echo e($reservation->id); ?> - <?php echo e(optional(optional($reservation->place)->site)->nom ?? 'Site N/A'); ?></h3>
                                            <p class="text-sm text-gray-500 flex items-center gap-1">
                                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
                                                </svg>
                                                <?php echo e(optional(optional($reservation->place)->site)->adresse ?? 'Adresse N/A'); ?>

                                            </p>
                                            <div class="flex items-center gap-4 mt-3 text-xs">
                                                <div class="flex items-center gap-1 text-gray-600">
                                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                                                    </svg>
                                                    <span class="font-medium"><?php echo e(\Carbon\Carbon::parse($reservation->date_debut)->format('d M Y')); ?></span>
                                                </div>
                                                <div class="flex items-center gap-1 text-gray-600">
                                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                                    </svg>
                                                    <span class="font-medium"><?php echo e(\Carbon\Carbon::parse($reservation->date_debut)->format('H:i')); ?> - <?php echo e(\Carbon\Carbon::parse($reservation->date_fin)->format('H:i')); ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Badges & Actions -->
                                <div class="flex flex-col items-end gap-3">
                                    <div class="flex items-center gap-2">
                                        <?php
                                            $isCompleted = $reservation->statut === 'confirmée'
                                                && $reservation->date_fin
                                                && \Carbon\Carbon::parse($reservation->date_fin)->isPast();
                                        ?>
                                        <?php if($isCompleted): ?>
                                            <span class="px-3 py-1.5 bg-blue-100 text-blue-700 rounded-xl text-xs font-black uppercase tracking-wider">✓ Terminée</span>
                                        <?php elseif($reservation->statut === 'confirmée'): ?>
                                            <span class="px-3 py-1.5 bg-green-100 text-green-700 rounded-xl text-xs font-black uppercase tracking-wider">✓ Confirmée</span>
                                        <?php elseif($reservation->statut === 'en_attente'): ?>
                                            <span class="px-3 py-1.5 bg-yellow-100 text-yellow-700 rounded-xl text-xs font-black uppercase tracking-wider">⏱ En attente</span>
                                        <?php elseif($reservation->statut === 'annulée'): ?>
                                            <span class="px-3 py-1.5 bg-red-100 text-red-700 rounded-xl text-xs font-black uppercase tracking-wider">✕ Annulée</span>
                                        <?php else: ?>
                                            <span class="px-3 py-1.5 bg-gray-100 text-gray-700 rounded-xl text-xs font-black uppercase tracking-wider"><?php echo e($reservation->statut); ?></span>
                                        <?php endif; ?>

                                        <?php if($reservation->payment_status === 'paid'): ?>
                                            <span class="px-3 py-1.5 bg-emerald-100 text-emerald-700 rounded-xl text-xs font-black">💳 Payé</span>
                                        <?php elseif($reservation->payment_status === 'failed'): ?>
                                            <span class="px-3 py-1.5 bg-red-100 text-red-700 rounded-xl text-xs font-black">💳 Échec</span>
                                        <?php elseif($reservation->payment_status === 'refunded'): ?>
                                            <span class="px-3 py-1.5 bg-orange-100 text-orange-700 rounded-xl text-xs font-black">💰 Remboursé</span>
                                        <?php else: ?>
                                            <span class="px-3 py-1.5 bg-gray-100 text-gray-700 rounded-xl text-xs font-black">💳 En attente</span>
                                        <?php endif; ?>
                                    </div>

                                    <!-- Boutons d'action -->
                                    <div class="flex items-center gap-2">
                                        <a href="<?php echo e(route('reservations.show', $reservation->id)); ?>" class="px-4 py-2 bg-gray-50 text-gray-700 rounded-xl text-xs font-bold hover:bg-gray-100 transition-all">
                                            Détails
                                        </a>

                                        <?php if($reservation->user_id === auth()->id() && $reservation->payment_status === 'pending'): ?>
                                            <form method="POST" action="<?php echo e(route('reservations.payer', $reservation->id)); ?>" class="inline-block">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="px-4 py-2 bg-green-600 text-white rounded-xl text-xs font-bold hover:bg-green-700 transition-all shadow-sm">
                                                    💳 Payer
                                                </button>
                                            </form>
                                        <?php endif; ?>

                                        <?php if($reservation->user_id === auth()->id() && $reservation->statut !== 'annulée'): ?>
                                            <form method="POST" action="<?php echo e(route('reservations.destroy', $reservation->id)); ?>" onsubmit="return confirm('Annuler cette réservation ?');" class="inline-block">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="px-4 py-2 bg-red-50 text-red-600 rounded-xl text-xs font-bold hover:bg-red-100 transition-all">
                                                    Annuler
                                                </button>
                                            </form>
                                        <?php endif; ?>

                                        <?php if(isset($reservation->place->site) && $reservation->place->site->user_id === auth()->id() && $reservation->statut === 'en_attente'): ?>
                                            <div x-data="{ showConfirmModal: false, showRefuseModal: false }">
                                                
                                                <button @click="showConfirmModal = true" type="button" class="px-4 py-2 bg-green-600 text-white rounded-xl text-xs font-bold hover:bg-green-700 transition-all">
                                                    ✓ Valider
                                                </button>
                                                
                                                <button @click="showRefuseModal = true" type="button" class="px-4 py-2 bg-orange-600 text-white rounded-xl text-xs font-bold hover:bg-orange-700 transition-all">
                                                    ✕ Refuser
                                                </button>

                                                
                                                <div x-show="showConfirmModal" x-cloak class="fixed inset-0 z-50 overflow-y-auto" aria-modal="true">
                                                    <div class="flex min-h-screen items-center justify-center p-4">
                                                        <div x-show="showConfirmModal" class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" @click="showConfirmModal = false"></div>
                                                        <div x-show="showConfirmModal" class="relative bg-white rounded-2xl shadow-xl max-w-md w-full p-6 transform transition-all">
                                                            <h3 class="text-lg font-bold text-gray-900 mb-4">Confirmer la réservation</h3>
                                                            <form method="POST" action="<?php echo e(route('reservations.valider', $reservation->id)); ?>">
                                                                <?php echo csrf_field(); ?>
                                                                <div class="mb-4">
                                                                    <label for="owner_message_confirm_<?php echo e($reservation->id); ?>" class="block text-sm font-medium text-gray-700 mb-1">Message pour le locataire (optionnel)</label>
                                                                    <textarea id="owner_message_confirm_<?php echo e($reservation->id); ?>" name="owner_message" rows="3" class="w-full rounded-lg border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500" placeholder="Ex: Code portail 1234, place à gauche..."></textarea>
                                                                </div>
                                                                <div class="flex justify-end gap-3">
                                                                    <button type="button" @click="showConfirmModal = false" class="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg font-medium hover:bg-gray-200">Annuler</button>
                                                                    <button type="submit" class="px-4 py-2 bg-green-600 text-white rounded-lg font-bold hover:bg-green-700">✓ Confirmer</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>

                                                
                                                <div x-show="showRefuseModal" x-cloak class="fixed inset-0 z-50 overflow-y-auto" aria-modal="true">
                                                    <div class="flex min-h-screen items-center justify-center p-4">
                                                        <div x-show="showRefuseModal" class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" @click="showRefuseModal = false"></div>
                                                        <div x-show="showRefuseModal" class="relative bg-white rounded-2xl shadow-xl max-w-md w-full p-6 transform transition-all">
                                                            <h3 class="text-lg font-bold text-gray-900 mb-4">Refuser la réservation</h3>
                                                            <form method="POST" action="<?php echo e(route('reservations.refuser', $reservation->id)); ?>">
                                                                <?php echo csrf_field(); ?>
                                                                <div class="mb-4">
                                                                    <label for="owner_message_refuse_<?php echo e($reservation->id); ?>" class="block text-sm font-medium text-gray-700 mb-1">Raison du refus (optionnel)</label>
                                                                    <textarea id="owner_message_refuse_<?php echo e($reservation->id); ?>" name="owner_message" rows="3" class="w-full rounded-lg border-gray-300 shadow-sm focus:border-orange-500 focus:ring-orange-500" placeholder="Ex: Place non disponible, travaux en cours..."></textarea>
                                                                </div>
                                                                <div class="flex justify-end gap-3">
                                                                    <button type="button" @click="showRefuseModal = false" class="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg font-medium hover:bg-gray-200">Annuler</button>
                                                                    <button type="submit" class="px-4 py-2 bg-orange-600 text-white rounded-lg font-bold hover:bg-orange-700">✕ Refuser</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="bg-white rounded-2xl border-2 border-dashed border-gray-200 p-12 text-center">
                        <div class="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
                            <svg class="w-10 h-10 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
                            </svg>
                        </div>
                        <h3 class="text-xl font-bold text-gray-900 mb-2">Aucune réservation</h3>
                        <p class="text-gray-500 mb-6">Vous n'avez pas encore de réservation. Commencez par réserver une place !</p>
                        <a href="<?php echo e(route('reservations.create')); ?>" class="inline-flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                            </svg>
                            Réserver maintenant
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH X:\Dev\f-web\ePark\epark_app\resources\views/reservations/index.blade.php ENDPATH**/ ?>