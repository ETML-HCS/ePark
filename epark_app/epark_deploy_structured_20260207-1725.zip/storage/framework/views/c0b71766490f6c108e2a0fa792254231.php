<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['as' => 'a']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['as' => 'a']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
	$baseClasses = 'block w-full px-4 py-2 text-start text-sm leading-5 text-gray-700 hover:bg-gray-100 focus:outline-none focus:bg-gray-100 transition duration-150 ease-in-out';
?>

<?php if($as === 'button'): ?>
	<button type="submit" <?php echo e($attributes->merge(['class' => $baseClasses])->except('as')); ?>>
		<?php echo e($slot); ?>

	</button>
<?php else: ?>
	<a <?php echo e($attributes->merge(['class' => $baseClasses])->except('as')); ?>><?php echo e($slot); ?></a>
<?php endif; ?>
<?php /**PATH X:\Dev\f-web\ePark\epark_app\resources\views/components/dropdown-link.blade.php ENDPATH**/ ?>