<?php echo e($slot); ?>

<?php /**PATH X:\Dev\f-web\ePark\epark_app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>