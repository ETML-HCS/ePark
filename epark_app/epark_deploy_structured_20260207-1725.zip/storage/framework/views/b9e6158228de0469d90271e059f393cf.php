<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="scroll-smooth">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'ePark')); ?> - <?php echo e(isset($title) ? $title : 'Tableau de bord'); ?></title>

        <!-- Favicon -->
        <link rel="icon" type="image/png" href="<?php echo e(asset('logo/ePark.png')); ?>" />

        <!-- Police Figtree (Moderne & Rond) -->
        <link rel="preconnect" href="https://fonts.bunny.net ">
        <link href="https://fonts.bunny.net/css?family=figtree:300 ,400,500,600,700&display=swap" rel="stylesheet" />

        <!-- Scripts & Styles via Vite -->
        
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    
    
    <body class="font-sans antialiased text-gray-900 bg-gray-50 dark:bg-gray-900 dark:text-gray-100 flex flex-col min-h-screen transition-colors duration-200">
        
        <?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!-- En-tête de page optionnel (Header) -->
        <?php if(isset($header)): ?>
            <header class="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 shadow-sm transition-colors duration-200">
                <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                    <h1 class="text-2xl font-bold text-gray-900 dark:text-white leading-tight">
                        <?php echo e($header); ?>

                    </h1>
                </div>
            </header>
        <?php endif; ?>

        <!-- Contenu Principal -->
        <main class="flex-grow w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <!-- Card Container pour un look propre -->
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 min-h-[500px] transition-colors duration-200">
                <div class="p-6 sm:p-8">
                    
                    
                    <?php if(isset($slot)): ?>
                        <?php echo e($slot); ?>

                    <?php endif; ?>
                    
                    
                    
                    
                </div>
            </div>
        </main>

        <!-- Footer Simple -->
        <footer class="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 mt-auto transition-colors duration-200">
            <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row justify-between items-center text-sm text-gray-500 dark:text-gray-400 gap-4">
                <p>&copy; <?php echo e(date('Y')); ?> ePark. Tous droits réservés.</p>
                <div class="flex space-x-6">
                    <a href="#" class="hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">Support</a>
                    <a href="#" class="hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">Mentions Légales</a>
                </div>
            </div>
        </footer>

        <!-- Scripts JS (Flash messages, etc.) -->
        <script>
            document.addEventListener('DOMContentLoaded', () => {
                // Fermeture automatique des alertes (Flash messages)
                const alerts = document.querySelectorAll('[data-dismiss="alert"]');
                alerts.forEach(alert => {
                    setTimeout(() => {
                        alert.style.transition = 'opacity 0.5s ease-out, transform 0.5s ease-out';
                        alert.style.opacity = '0';
                        alert.style.transform = 'translateY(-10px)';
                        setTimeout(() => {
                            alert.remove();
                        }, 500);
                    }, 5000);
                });
            });
        </script>
        <?php echo $__env->yieldPushContent('scripts'); ?>
    </body>
</html><?php /**PATH X:\Dev\f-web\ePark\epark_app\resources\views\layouts\app.blade.php ENDPATH**/ ?>