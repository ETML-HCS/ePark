<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH X:\Dev\f-web\ePark\epark_app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>