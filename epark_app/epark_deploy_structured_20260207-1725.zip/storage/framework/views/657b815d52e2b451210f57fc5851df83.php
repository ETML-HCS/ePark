<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'variant' => 'primary', // Permet de changer la couleur si besoin (primary, danger, etc.)
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'variant' => 'primary', // Permet de changer la couleur si besoin (primary, danger, etc.)
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    // Classes de base communes
    $baseClasses = 'inline-flex items-center justify-center px-4 py-2 border font-medium text-sm rounded-lg shadow-sm transition-all duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed active:scale-95';

    // Variantes de couleurs (Extensible pour les boutons rouge, vert, etc.)
    $variants = [
        'primary' => 'bg-indigo-600 border-transparent text-white hover:bg-indigo-700 active:bg-indigo-800 focus:ring-indigo-500 focus:ring-offset-white dark:focus:ring-offset-gray-800 disabled:hover:bg-indigo-600',
        // Exemple pour un bouton 'danger' (si tu veux l'utiliser plus tard) :
        // 'danger' => 'bg-red-600 border-transparent text-white hover:bg-red-700 focus:ring-red-500',
    ];

    // Fusion de tout
    $computedClasses = $baseClasses . ' ' . ($variants[$variant] ?? $variants['primary']);
?>

<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => $computedClasses])); ?>>
    <?php echo e($slot); ?>

</button><?php /**PATH X:\Dev\f-web\ePark\epark_app\resources\views\components\primary-button.blade.php ENDPATH**/ ?>